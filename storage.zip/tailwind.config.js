const colors = require('tailwindcss/colors');

module.exports = {
    mode: 'jit',
    purge: [
        './app/Units/Portal/resources/views/**/*.blade.php',
        './storage/framework/views/*.php',
        './app/Units/Portal/resources/js/**/*.js',
        './app/Units/Portal/resources/js/**/*.vue',
    ],
    darkMode: false, // or 'media' or 'class'
    theme: {
        extend: {
            zIndex: {
                '75': 75,
                '100': 100,
                'auto': 'auto',
                '-10': '-1',
            },
            colors: {
                gray: colors.blueGray,
                primary: {
                    lightest: '#ffa16f',
                    light: '#ff8040',
                    DEFAULT: '#f36f21',
                    dark: '#e05326',
                    darkest: '#b7340d',
                },
                black: {
                    lightest: '#abacac',
                    light: '#58595b',
                    DEFAULT: '#1a1517',
                    //dark: '#e05326',
                    //darkest: '#b7340d',
                },
                'wpp-color': {
                    DEFAULT: '#25d366',
                }
            }
        },
        // fontFamily: {
        //     'sans': "'Montserrat', sans-serif"
        // },
    },
    variants: {
        extend: {},
    },
    plugins: [
        require('@tailwindcss/forms'),
    ],
    corePlugins: {
        container: false,
    }
}
