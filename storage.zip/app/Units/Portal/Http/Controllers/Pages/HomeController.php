<?php

namespace PortalApp\Http\Controllers\Pages;

use PortalApp\Http\Controllers\BaseController;

class HomeController extends BaseController
{
    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index()
    {
        $this->seo()->setTitle('MM Racing Fuel');
        $this->seo()->setDescription('Description da página');

        return $this->view('pages.home.index');
    }
    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index2()
    {
        $this->seo()->setTitle('Titulo da página');
        $this->seo()->setDescription('Description da página');

        return $this->view('pages.home.index2');
    }
}
