@extends('portal::layouts.error-pages')
<section class="h-full flex flex-wrap content-center">
    <div class="container sm:w-11/12 mx-auto text-center">
        <a href="{{ route($locale_prefix . '_home') }}"
            class="max-w-xs p-5 flex m-auto rounded-md">
            <svg class="logo text-white"
                 viewBox="0 0 200 86">
                <use x="0" y="0" xlink:href="#logo-alphafish"></use>
            </svg>
        </a>
        
        <h1 class="text-4xl mb-8">Página não encontrada</h1>

        <a href="/"
           data-turbolinks="false"
           class="inline-flex px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue hover:bg-blue-dark md:py-4 md:text-lg md:px-10 transition">
            Voltar ao início
        </a>

    </div>
</section>
