<script src="{{ mix('/static-files/portal/js/app.js') }}"></script>

@stack('scripts')
