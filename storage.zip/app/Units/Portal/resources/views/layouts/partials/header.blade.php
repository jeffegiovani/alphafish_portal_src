<header class="fixed inset-x-0 top-0 w-full z-75 text-white bg-black"
        id="main-header-app"
        x-data="MainHeader"
        x-init="$nextTick(() => { onScroll() })"
        x-cloak
        x-on:scroll.window="onScroll()"
        x-on:keydown.escape="showMobileMenu = false">
    <div id="pre-header"
         class="relative transition-all duration-300 z-50"
         x-bind:class="{'bg-black': showBgColor, 'py-4': !isSlim, 'py-2': isSlim}">
        <div class="container mx-auto">
            <div class="flex flex-wrap justify-between items-center lg:flex-row">
                <div class="flex justify-start">
                    <a href="{{ route($locale_prefix . '_home') }}">
                        <span class="sr-only">{!! __('Alpha Fish') !!}</span>
                        <svg class="logo min-w-1/4 text-white fill-current transition-all duration-300"
                             viewBox="0 0 200 86"
                             x-bind:class="{'w-28 md:w-36': !isSlim, 'w-20 md:w-28': isSlim,}">
                            <use x="0" y="0" xlink:href="#logo-alphafish"></use>
                        </svg>
                    </a>
                </div>

{{--                <form action="{{ route($locale_prefix . '_home') }}"--}}
{{--                      method="post"--}}
{{--                      class="hidden lg:inline-flex flex-1 px-6 xl:px-32"--}}
{{--                      x-bind:class="{'opacity-25': loading}"--}}
{{--                      @submit.prevent="submitForm()">--}}
{{--                    <div class="floating-label z-0 w-full group">--}}
{{--                        <input--}}
{{--                                type="text"--}}
{{--                                name="search_term"--}}
{{--                                id="search_term"--}}
{{--                                placeholder=" "--}}
{{--                                maxlength="70"--}}
{{--                                x-model="formData.name"--}}
{{--                                class="block w-full rounded-md bg-gray-100 border-2 border-transparent focus:border-gray-200 focus:bg-white focus:ring-0 transition duration-300"--}}
{{--                        />--}}
{{--                        <label for="search_term"--}}
{{--                               class="absolute rounded-full duration-300 top-3 origin-0 text-gray-500 ml-1 px-3 group-focus:bg-white">--}}
{{--                            O que você procura?--}}
{{--                        </label>--}}
{{--                        <template x-if="errors.name">--}}
{{--                            <div class="text-red-600 px-4 text-sm" x-html="errors.name[0]"></div>--}}
{{--                        </template>--}}
{{--                    </div>--}}
{{--                </form>--}}

                <nav class="hidden lg:flex space-x-px">
                    <a href="{{ route($locale_prefix . '_nitrometano') }}"
                       class="py-2 px-2 md:px-4 hover:bg-white hover:text-primary transition duration-300">
                        Nitrometano
                    </a>
                    <span class="py-2 text-xs opacity-40">|</span>
                    <a href="{{ route($locale_prefix . '_metanol') }}"
                       class="py-2 px-2 md:px-4 hover:bg-white hover:text-primary transition duration-300"
                       title="MM">
                        Metanol
                    </a>
                    <span class="py-2 text-xs opacity-40">|</span>
                    <a href="{{ route($locale_prefix . '_m5') }}"
                       class="py-2 px-2 md:px-4 hover:bg-white hover:text-primary transition duration-300">
                        M5 Faster Combustion
                    </a>
                </nav>

                {{-- Mobile hamburguer menu end search icons --}}
                <div class="flex content-center lg:hidden gap-2">
{{--                    <a href="{{ route($locale_prefix . '_home') }}"--}}
{{--                       class="flex flex-wrap content-center whitespace-nowrap text-base font-medium text-white hover:text-blue-300 transition duration-200">--}}
{{--                        <svg class="w-10 h-10 outline-icon non-scaling-stroke stroke-2" viewBox="0 0 24 24">--}}
{{--                            <use x="0" y="0" xlink:href="#line-search-circle"></use>--}}
{{--                        </svg>--}}
{{--                    </a>--}}

{{--                    <a href="{{ route($locale_prefix . '_home') }}"--}}
{{--                       class="flex flex-wrap content-center whitespace-nowrap text-base font-medium text-white hover:text-blue-300 transition duration-200">--}}
{{--                        <svg class="w-10 h-10 outline-icon non-scaling-stroke stroke-2" viewBox="0 0 24 24">--}}
{{--                            <use x="0" y="0" xlink:href="#line-search-circle"></use>--}}
{{--                        </svg>--}}
{{--                    </a>--}}

                    <button type="button"
                            class="bg-transparent border-2 border-white rounded-full p-2 inline-flex items-center justify-center text-white focus:outline-none"
                            aria-expanded="false"
                            x-on:click="toggleMobileMenu()"
                            name="open-menu">
                        <span class="sr-only">Abrir menu</span>
                        <svg class="w-6 h-6 outline-icon non-scaling-stroke stroke-2" viewBox="0 0 24 24">
                            <use x="0" y="0" xlink:href="#line-menu"></use>
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div id="main-header"
         class="absolute inset-x-0 transition-all duration-300 z-10 hidden"
         x-bind:class="{'bg-primary': showBgColor,'bg-black': !showBgColor, 'shadow-xl': showBgColor, 'top-0': hidePreHeader, 'top-full': !hidePreHeader}">

        <div class="h-px bg-black-light opacity-25"></div>

        <div class="container mx-auto">
            <div class="flex justify-between items-center transition-all duration-300"
                 x-bind:class="{'menu-slim': isSlim}">


                {{-- Desktop Header Items --}}
                <nav class="hidden md:flex justify-center w-full">
                    <div class="relative group">
                        <button type="button"
                                class="group text-white group-hover:text-black bg-transparent group-hover:bg-white p-2 xl:p-3 2xl:p-4 inline-flex items-center font-medium focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition duration-300"
                                aria-expanded="false"
                                name="open-segments">
                            <span>{!! __('Combustíveis') !!}</span>
                            <svg class="text-white ml-1 h-5 w-5 group-hover:text-black transform group-hover:-rotate-180 transition"
                                 viewBox="0 0 20 20">
                                <use x="0" y="0" class="fill-current" xlink:href="#solid-chevron-down"></use>
                            </svg>
                        </button>
                        <div class="absolute z-10 invisible group-hover:visible opacity-0 group-hover:opacity-100 left-1/2 transform -translate-x-1/2 scale-90 group-hover:scale-100 w-screen max-w-xs transition duration-300 ease-out">
                            <div class="rounded shadow-lg overflow-y-auto max-h-screen-80">
                                <div class="relative bg-white p-px">
                                    <a href="{{ route($locale_prefix . '_home') }}"
                                       class="px-4 py-2 flex items-start rounded hover:bg-black text-black hover:text-white transition duration-300">
                                        {!! __('Categoria 1') !!}
                                    </a>
                                    <a href="{{ route($locale_prefix . '_home') }}"
                                       class="px-4 py-2 flex items-start rounded hover:bg-black text-black hover:text-white transition duration-300">
                                        {!! __('Categoria 2') !!}
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="relative group">
                        <button type="button"
                                class="group text-white group-hover:text-black bg-transparent group-hover:bg-white p-2 xl:p-3 2xl:p-4 inline-flex items-center font-medium focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition duration-300"
                                aria-expanded="false"
                                name="open-segments">
                            <span>{!! __('Motor Forjado') !!}</span>
                            <svg class="text-white ml-1 h-5 w-5 group-hover:text-black transform group-hover:-rotate-180 transition"
                                 viewBox="0 0 20 20">
                                <use x="0" y="0" class="fill-current" xlink:href="#solid-chevron-down"></use>
                            </svg>
                        </button>
                        <div class="absolute z-10 invisible group-hover:visible opacity-0 group-hover:opacity-100 left-1/2 transform -translate-x-1/2 scale-90 group-hover:scale-100 w-screen max-w-xs transition duration-300 ease-out">
                            <div class="rounded shadow-lg overflow-y-auto max-h-screen-80">
                                <div class="relative bg-white p-px">
                                    <a href="{{ route($locale_prefix . '_home') }}"
                                       class="px-4 py-2 flex items-start rounded hover:bg-black text-black hover:text-white transition duration-300">
                                        {!! __('Categoria 1') !!}
                                    </a>
                                    <a href="{{ route($locale_prefix . '_home') }}"
                                       class="px-4 py-2 flex items-start rounded hover:bg-black text-black hover:text-white transition duration-300">
                                        {!! __('Categoria 2') !!}
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="relative group">
                        <button type="button"
                                class="group text-white group-hover:text-black bg-transparent group-hover:bg-white p-2 xl:p-3 2xl:p-4 inline-flex items-center font-medium focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition duration-300"
                                aria-expanded="false"
                                name="open-segments">
                            <span>{!! __('Pneus') !!}</span>
                            <svg class="text-white ml-1 h-5 w-5 group-hover:text-black transform group-hover:-rotate-180 transition"
                                 viewBox="0 0 20 20">
                                <use x="0" y="0" class="fill-current" xlink:href="#solid-chevron-down"></use>
                            </svg>
                        </button>
                        <div class="absolute z-10 invisible group-hover:visible opacity-0 group-hover:opacity-100 left-1/2 transform -translate-x-1/2 scale-90 group-hover:scale-100 w-screen max-w-xs transition duration-300 ease-out">
                            <div class="rounded shadow-lg overflow-y-auto max-h-screen-80">
                                <div class="relative bg-white p-px">
                                    <a href="{{ route($locale_prefix . '_home') }}"
                                       class="px-4 py-2 flex items-start rounded hover:bg-black text-black hover:text-white transition duration-300">
                                        {!! __('Categoria 1') !!}
                                    </a>
                                    <a href="{{ route($locale_prefix . '_home') }}"
                                       class="px-4 py-2 flex items-start rounded hover:bg-black text-black hover:text-white transition duration-300">
                                        {!! __('Categoria 2') !!}
                                    </a>
                                    <a href="{{ route($locale_prefix . '_home') }}"
                                       class="px-4 py-2 flex items-start rounded hover:bg-black text-black hover:text-white transition duration-300">
                                        {!! __('Categoria 1') !!}
                                    </a>
                                    <a href="{{ route($locale_prefix . '_home') }}"
                                       class="px-4 py-2 flex items-start rounded hover:bg-black text-black hover:text-white transition duration-300">
                                        {!! __('Categoria 2') !!}
                                    </a>
                                    <a href="{{ route($locale_prefix . '_home') }}"
                                       class="px-4 py-2 flex items-start rounded hover:bg-black text-black hover:text-white transition duration-300">
                                        {!! __('Categoria 1') !!}
                                    </a>
                                    <a href="{{ route($locale_prefix . '_home') }}"
                                       class="px-4 py-2 flex items-start rounded hover:bg-black text-black hover:text-white transition duration-300">
                                        {!! __('Categoria 2') !!}
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                </nav>
            </div>
        </div>

        <div class="h-px bg-black-light opacity-25"></div>
    </div>


    {{-- Mobile menu, show/hide based on mobile menu state --}}
    @include('portal::layouts.partials.mobile-menu')

    @if(!is_active($locale_prefix . '_mainstream'))
        <div class="fixed inset-x-0 bottom-0 w-full z-75 bg-primary text-white transition-all duration-700 overflow-y-hidden"
             x-bind:class="{'max-h-0': !hidePreHeader, 'max-h-20 lg:max-h-20 border-t border-primary-light': hidePreHeader}">
            <div class="flex items-center justify-center w-full">
                <div class="p-2">Fale conosco pelo WhatsApp | Site seguro</div>
            </div>
        </div>
    @endif

</header>
