
<link rel="apple-touch-icon" sizes="180x180" href="{{ config('app.asset_url') }}portal/favicons/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="{{ config('app.asset_url') }}portal/favicons/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="{{ config('app.asset_url') }}portal/favicons/favicon-16x16.png">
<link rel="manifest" href="{{ config('app.asset_url') }}portal/favicons/site.webmanifest">
<link rel="mask-icon" href="{{ config('app.asset_url') }}portal/favicons/safari-pinned-tab.svg" color="#000000">
<link rel="shortcut icon" href="{{ config('app.asset_url') }}portal/favicons/favicon.ico">
<meta name="apple-mobile-web-app-title" content="Portal">
<meta name="application-name" content="PortalApp">
<meta name="msapplication-TileColor" content="#00000">
<meta name="msapplication-config" content="{{ config('app.asset_url') }}portal/favicons/browserconfig.xml">
<meta name="theme-color" content="#000000">
