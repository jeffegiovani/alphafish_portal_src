{{--{{ dd(readfile(public_path(mix('/static-files/portal/css/portal.css')))) }}--}}
{{--<link rel="stylesheet" href="{{ mix('/static-files/portal/css/portal.css') }}">--}}

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="{{ mix('/static-files/portal/css/portal.css') }}">
<style>
    {{--!! str_replace('@charset "UTF-8";', '', file_get_contents(public_path('/static-files/portal/css/portal.css'))) !!--}}
    {{--    @php str_replace('@charset "UTF-8";', '', readfile(public_path('/static-files/portal/css/portal.css'))) @endphp--}}
</style>
{{--<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,400;0,700;1,400&display=swap" rel="stylesheet">--}}
<link rel="preload" href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,400;0,700;1,400&display=swap" as="style" onload="this.onload=null;this.rel='stylesheet'">
{{--
@if(!Browser::isMobile())
    { {--<link rel="stylesheet" href="{{ config('app.asset_url') . str_replace('/static-files/', '', mix('/static-files/portal/css/app.css')) }}" data-turbolinks-track="true">--} }
    <link rel="stylesheet" href="{{ mix('/static-files/portal/css/app.css') }}" data-turbolinks-track="true">
@endif
@if(Browser::isMobile())
    <link rel="stylesheet" href="{{ mix('/static-files/portal/css/app.css') }}" data-turbolinks-track="true">
@endif
--}}

<link rel="preload"
      href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,600;1,400&display=swap"
      as="style"
      onload="this.onload=null;this.rel='stylesheet'">