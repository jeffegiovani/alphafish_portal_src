@extends('portal::layouts.portal-pages')

@section('page_content')

    <section>
        <div class="container mx-auto">
            Teste
        </div>
    </section>

@endsection
