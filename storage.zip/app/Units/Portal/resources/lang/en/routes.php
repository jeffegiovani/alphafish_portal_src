<?php
 return [
     'contact' => 'contact',
     'product_details' => 'details',
     'list_products' => 'products',
     'partners' => 'partners',
 ];