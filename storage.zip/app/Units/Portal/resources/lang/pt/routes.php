<?php
 return [
     'contact' => 'contato',
     'product_details' => 'detalhes',
     'list_products' => 'produtos',
     'partners' => 'contato',
 ];