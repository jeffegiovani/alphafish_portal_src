<?php

namespace CoreApp\Providers;

use Illuminate\Support\ServiceProvider;

class CarbonLangProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        /*setlocale(LC_ALL, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
        date_default_timezone_set('America/Sao_Paulo');*/
        \Carbon\Carbon::setLocale($this->app->getLocale());
    }
}
